README



Abra os arquivos no editor de código de sua escolha e comece a substituir os itens.
Obs.: Atente-se ao formato, TAMANHO e ao NOME das imagens que estão no projeto, as suas precisam ter os mesmos tamanhos e os mesmos nomes.
A cor fica por sua escolha e criatividade. Se quiser adicionar outras sessões fique a vontade também.