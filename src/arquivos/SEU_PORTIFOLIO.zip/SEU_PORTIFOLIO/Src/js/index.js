const projetos = document.querySelectorAll('.projeto');
const btnMostrarProjetos = document.querySelector('.btn-mostrar-projetos');
let projetosVisiveis = false;

function alternarVisibilidade() {
  projetos.forEach((projeto, index) => {
    if (projetosVisiveis) {
      if (index >= 4) {
        projeto.style.display = 'none';
      }
    } else {
      projeto.style.display = 'block';
    }
  });

  if (projetosVisiveis) {
    btnMostrarProjetos.textContent = 'Mostrar mais';
  } else {
    btnMostrarProjetos.textContent = 'Mostrar menos';
  }

  projetosVisiveis = !projetosVisiveis;
}